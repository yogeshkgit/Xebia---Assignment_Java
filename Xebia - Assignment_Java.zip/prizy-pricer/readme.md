Clone Project
-------------
git clone https://github.com/guptasujeet/dynamic-pricer.git


App Usage
---------
cd dynamic-pricer <br>
mvn clean install <br>
java -jar target/dynamic-pricer-1.1.8.RELEASE.jar <br> 


Skip Tests
----------
mvn clean install -DskipTests <br>


Debug Mode
----------------
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005 -jar target/dynamic-pricer-1.1.8.RELEASE.jar


Save Product
-------------
curl -v -X POST -H "Content-Type: application/json" -d '{"barcode" : "B12BUU33", "name" : "Product 1"}'  http://localhost:8080/product


GET Product
------------
http://localhost:8080/product/1


Get Survey Data
----------------
http://localhost:8080/productSurvey/1


Get Price Details
-----------------
http://localhost:8080/getProductPriceDetails/barcode <br>
http://localhost:8080/getProductPriceDetails/B1234 


