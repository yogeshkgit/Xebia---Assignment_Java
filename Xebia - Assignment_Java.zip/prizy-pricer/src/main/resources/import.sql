
insert into product (product_id, barcode, name) values (1, 'B01', 'Note 5' );
insert into product (product_id, barcode, name) values (2, 'B02', 'Note 6' );
insert into product (product_id, barcode, name) values (3, 'B03', 'Note 7' );
insert into product (product_id, barcode, name) values (4, 'SH245', 'iPhone6' );
insert into product (product_id, barcode, name) values (5, 'SH233', 'iPhone6s' );
insert into product (product_id, barcode, name) values (6, 'SH245', 'iPhone8' );
insert into product (product_id, barcode, name) values (7, 'SH267', 'iPhone10' );


insert into product_survey (product_survey_id, product_id, price, store_name ) values (1, 1, 22.2, 'Shop 1' );
insert into product_survey (product_survey_id, product_id, price, store_name ) values (2, 4, 23.7, 'Shop 2' );
insert into product_survey (product_survey_id, product_id, price, store_name ) values (3, 5, 20.5, 'Shop 3' );
insert into product_survey (product_survey_id, product_id, price, store_name ) values (4, 7, 20.5, 'Shop 4' );




