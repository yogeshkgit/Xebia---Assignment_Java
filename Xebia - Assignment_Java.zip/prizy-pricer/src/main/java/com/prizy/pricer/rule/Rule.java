package com.prizy.pricer.rule;


public interface Rule {
}
