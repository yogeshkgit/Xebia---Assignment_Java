package com.prizy.pricer.dto;


import com.prizy.pricer.domain.Product;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ProductPriceDetail {
    private Product product;
    private BigDecimal idealPrice;
    private BigDecimal averagePrice;
    private BigDecimal lowestPrice;
    private BigDecimal highestPrice;
	public Product getProduct() {
		return this.product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public BigDecimal getIdealPrice() {
		return this.idealPrice;
	}
	public void setIdealPrice(BigDecimal idealPrice) {
		this.idealPrice = idealPrice;
	}
	public BigDecimal getAveragePrice() {
		return this.averagePrice;
	}
	public void setAveragePrice(BigDecimal averagePrice) {
		this.averagePrice = averagePrice;
	}
	public BigDecimal getLowestPrice() {
		return this.lowestPrice;
	}
	public void setLowestPrice(BigDecimal lowestPrice) {
		this.lowestPrice = lowestPrice;
	}
	public BigDecimal getHighestPrice() {
		return this.highestPrice;
	}
	public void setHighestPrice(BigDecimal highestPrice) {
		this.highestPrice = highestPrice;
	}
    
    
}
