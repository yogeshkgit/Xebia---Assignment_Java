package com.prizy.pricer.compiler;

import com.prizy.pricer.beanshell.DynamicRuleInterpreter;
import com.prizy.pricer.exception.NoRuleClassFoundException;
import com.prizy.pricer.rule.Rule;
import lombok.extern.slf4j.Slf4j;

import javax.tools.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;


@Slf4j
public class RuleCompiler {
	private static final Logger log = LoggerFactory.getLogger(RuleCompiler.class);

    private static Map<Class<? extends Rule>,Object> clazzMap = new HashMap<>();

    public static Object getDynamicClass(Class<? extends Rule> ruleClazz){

        if(clazzMap.get(ruleClazz) != null){
            return clazzMap.get(ruleClazz);
        }else {
            Object clazzObject = null;
            try {
                clazzObject = loadClass(ruleClazz);
            } catch (ClassNotFoundException | IOException | InstantiationException | IllegalAccessException e) {
                e.printStackTrace();
            }
            return clazzObject;
        }
    }

    private static Object loadClass(Class<? extends Rule> ruleClazz) throws ClassNotFoundException, IOException, InstantiationException, IllegalAccessException {
        ResourceBundle bundle = ResourceBundle.getBundle("application");
        String ruleDirectory = bundle.getString("rule.directory");
        String ruleFilePath = ruleDirectory + File.separator + ruleClazz.getSimpleName() + "Impl.java";
        Object obj = null;
        File ruleFile = new File(ruleFilePath);
        System.setProperty("java.home", System.getenv("JAVA_HOME"));
        if (ruleFile.getParentFile().exists()) {
            try {
                DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
                JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
                StandardJavaFileManager fileManager = compiler.getStandardFileManager(diagnostics, null, null);               
                List<String> optionList = new ArrayList<>();
                optionList.add("-classpath");
                String ruleClassPath = ruleClazz.getProtectionDomain().getCodeSource().getLocation().getPath().replaceFirst("file:","").replaceAll("!/", "");
                optionList.add(System.getProperty("java.class.path") + File.pathSeparator +ruleClassPath + File.pathSeparator + "." +File.pathSeparator);
                optionList.add("-d");
                optionList.add(new File(ruleClassPath).getParent());

                Iterable<? extends JavaFileObject> compilationUnit= fileManager.getJavaFileObjectsFromFiles(Arrays.asList(ruleFile));
                JavaCompiler.CompilationTask task = compiler.getTask(null,fileManager,diagnostics,optionList,null,compilationUnit);
               
                if (task.call()) {         
                   
                    URLClassLoader classLoader = new URLClassLoader(new URL[]{new File(ruleClassPath).getParentFile().toURI().toURL()});
                    Class<?> loadedClass = classLoader.loadClass(ruleClazz.getSimpleName()+"Impl");
                    obj = loadedClass.newInstance();
                } else {
                    for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
                        log.error(String.format("Error on line %d in %s%n",diagnostic.getLineNumber(),diagnostic.getSource().toUri()));
                    }
                }
                fileManager.close();
            } catch (IOException | ClassNotFoundException | InstantiationException | IllegalAccessException exp) {
                log.error("error while loading class ", exp);
                throw exp;
            }
        }
        if(obj == null){
            throw new NoRuleClassFoundException("No Rule class found for :" + ruleClazz.getName());
        }
        return obj;
    }

}