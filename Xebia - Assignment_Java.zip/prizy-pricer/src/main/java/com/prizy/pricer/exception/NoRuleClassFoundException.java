package com.prizy.pricer.exception;


public class NoRuleClassFoundException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 8144248846222900795L;

	public NoRuleClassFoundException(String message) {
        super(message);
    }
}
